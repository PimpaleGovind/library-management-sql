# SQL Internship – Task 2

## Task: Data Insertion and Null Handling

This task includes data manipulation on the previously created `LibraryDB`.

### Operations Performed
- Inserted data into `Author`, `Book`, `Member`, `Librarian`, `Borrow`
- Used `NULL` values and partial inserts
- Applied `UPDATE` and `DELETE` with conditions
- Demonstrated inserting using `SELECT`
- Used `IS NULL`, `DEFAULT`, and error case for `NOT NULL`

### Files Included
- `task2.sql`: SQL file with DML operations
