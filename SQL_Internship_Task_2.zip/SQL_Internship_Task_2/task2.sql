USE LibraryDB;

-- Insert Authors
INSERT INTO Author (Name) VALUES 
('Chetan Bhagat'),
('J.K. Rowling'),
('R.K. Narayan');

-- Insert Books
INSERT INTO Book (Title, Genre, Publisher, Year) VALUES 
('Five Point Someone', 'Fiction', 'Rupa', 2004),
('Harry Potter', 'Fantasy', 'Bloomsbury', 1997),
('Malgudi Days', NULL, 'Indian Publishers', 1943); -- Genre is NULL

-- Insert Book-Author Links
INSERT INTO BookAuthor (BookID, AuthorID) VALUES
(1, 1), -- Five Point Someone - Chetan Bhagat
(2, 2), -- Harry Potter - J.K. Rowling
(3, 3); -- Malgudi Days - R.K. Narayan

-- Insert Members
INSERT INTO Member (Name, Email, Phone) VALUES
('Rahul Sharma', 'rahul@example.com', '9876543210'),
('Anjali Mehta', NULL, '9123456789'); -- Email is NULL

-- Insert Librarians
INSERT INTO Librarian (Name, Email) VALUES
('Deepa Nair', 'deepa@library.com');

-- Insert Borrows
INSERT INTO Borrow (BookID, MemberID, BorrowDate, ReturnDate) VALUES
(1, 1, '2025-06-01', '2025-06-10'),
(2, 2, '2025-06-05', NULL); -- ReturnDate is NULL

-- Update Member’s phone number
UPDATE Member
SET Phone = '9998887776'
WHERE Name = 'Anjali Mehta';

-- Update Borrow to set ReturnDate
UPDATE Borrow
SET ReturnDate = '2025-06-20'
WHERE BorrowID = 2;

-- Delete a BookAuthor record (if we want to simulate a removal)
DELETE FROM BookAuthor
WHERE BookID = 2 AND AuthorID = 2;

-- Insert using SELECT (insert duplicate member for demo)
INSERT INTO Member (Name, Email, Phone)
SELECT Name, Email, Phone FROM Member WHERE MemberID = 1;

-- Insert with partial columns (Phone left NULL)
INSERT INTO Member (Name, Email)
VALUES ('Vikas Patil', 'vikas@example.com');

-- Attempt to insert NULL into NOT NULL field (will throw error if uncommented)
-- INSERT INTO Book (Title) VALUES (NULL);
