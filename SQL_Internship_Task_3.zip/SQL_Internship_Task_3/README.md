
# SQL Internship – Task 3

## Task: Basic SELECT Queries

This task demonstrates how to extract and filter data using SQL SELECT statements.

### Key Concepts
- SELECT * and specific columns
- WHERE, AND, OR, LIKE, BETWEEN, IN
- ORDER BY and LIMIT
- Aliasing with AS
- DISTINCT values
- Filtering NULL values

### Files Included
- `task3.sql`: SQL file with all SELECT queries
