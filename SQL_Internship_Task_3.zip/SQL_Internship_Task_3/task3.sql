
USE LibraryDB;

-- 1. Select all columns from Book table
SELECT * FROM Book;

-- 2. Select specific columns from Member
SELECT Name, Email FROM Member;

-- 3. Filter: Get all books published after 2000
SELECT * FROM Book
WHERE Year > 2000;

-- 4. Filter with multiple conditions using AND
SELECT * FROM Book
WHERE Genre = 'Fiction' AND Publisher = 'Rupa';

-- 5. Use LIKE: Find members with email ending in 'example.com'
SELECT * FROM Member
WHERE Email LIKE '%example.com';

-- 6. Use BETWEEN: Books published between 1995 and 2005
SELECT * FROM Book
WHERE Year BETWEEN 1995 AND 2005;

-- 7. Sort books by Year descending
SELECT * FROM Book
ORDER BY Year DESC;

-- 8. Use LIMIT: Show only 2 most recent books
SELECT * FROM Book
ORDER BY Year DESC
LIMIT 2;

-- 9. Use alias for cleaner output
SELECT Name AS MemberName, Phone AS Contact FROM Member;

-- 10. Use DISTINCT: List unique genres
SELECT DISTINCT Genre FROM Book;

-- 11. = vs IN: Get books by specific publishers
SELECT * FROM Book
WHERE Publisher IN ('Rupa', 'Bloomsbury');

-- 12. Filter NULLs: Find books with unknown genre
SELECT * FROM Book
WHERE Genre IS NULL;
